<div align="center">

# 🛡️ Harsh Kumar

**SOC Analyst · DFIR Analyst · Endpoint Security Engineer**

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-0A66C2?style=flat-square&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/harsh-kumar-5a8b9b187)
[![GitHub](https://img.shields.io/badge/GitHub-Harshk7771-181717?style=flat-square&logo=github&logoColor=white)](https://github.com/Harshk7771)
[![Portfolio](https://img.shields.io/badge/Portfolio-Live-c8f135?style=flat-square&logo=githubpages&logoColor=black)](https://harshk7771.github.io)
[![NCIIPC](https://img.shields.io/badge/NCIIPC-4%20CVDs%20Disclosed-FF6B35?style=flat-square)](https://nciipc.gov.in)

</div>

---

## ⚔️ Technical Stack

### Endpoint Detection & Response
![Checkpoint](https://img.shields.io/badge/Checkpoint_EDR-FF0000?style=flat-square)
![Centralized AV](https://img.shields.io/badge/Centralized_AV-222?style=flat-square)
![IPS](https://img.shields.io/badge/IPS_/_IDS-333?style=flat-square)
![Anti-Malware](https://img.shields.io/badge/Anti--Malware-444?style=flat-square)
![NGAV](https://img.shields.io/badge/Next--Gen_AV-555?style=flat-square)
![Integrity Monitoring](https://img.shields.io/badge/Integrity_Monitoring-666?style=flat-square)
![Log Inspection](https://img.shields.io/badge/Log_Inspection-777?style=flat-square)

### DFIR Toolchain
![Autopsy](https://img.shields.io/badge/Autopsy-2C2C2C?style=flat-square)
![FTK Imager](https://img.shields.io/badge/FTK_Imager-333?style=flat-square)
![Wireshark](https://img.shields.io/badge/Wireshark-1679A7?style=flat-square&logo=wireshark&logoColor=white)
![Network Miner](https://img.shields.io/badge/Network_Miner-444?style=flat-square)
![Snort](https://img.shields.io/badge/Snort_IDS-E8002D?style=flat-square)
![BelkaGPT](https://img.shields.io/badge/BelkaGPT_DFIR-222?style=flat-square)
![Mobiledit](https://img.shields.io/badge/Mobiledit_Forensics-333?style=flat-square)

### Cyber Defense Frameworks
![MITRE ATT&CK](https://img.shields.io/badge/MITRE_ATT%26CK-003366?style=flat-square)
![Cyber Kill Chain](https://img.shields.io/badge/Cyber_Kill_Chain-8B0000?style=flat-square)
![Diamond Model](https://img.shields.io/badge/Diamond_Model-1A1A1A?style=flat-square)
![Pyramid of Pain](https://img.shields.io/badge/Pyramid_of_Pain-2D2D2D?style=flat-square)
![D3FEND](https://img.shields.io/badge/MITRE_D3FEND-004080?style=flat-square)

### SOC & Monitoring
![Alert Triage](https://img.shields.io/badge/Alert_Triage-333?style=flat-square)
![EDR/XDR Review](https://img.shields.io/badge/EDR_/_XDR_Review-444?style=flat-square)
![SIEM Analysis](https://img.shields.io/badge/SIEM_Analysis-555?style=flat-square)
![IOC Investigation](https://img.shields.io/badge/IOC_Investigation-666?style=flat-square)
![Incident Ticketing](https://img.shields.io/badge/Incident_Ticketing-777?style=flat-square)

### OS, Network & Scripting
![Kali Linux](https://img.shields.io/badge/Kali_Linux-268BEE?style=flat-square&logo=kalilinux&logoColor=white)
![Windows Server](https://img.shields.io/badge/Windows_Server-0078D6?style=flat-square&logo=windows&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white)
![Bash](https://img.shields.io/badge/Bash-4EAA25?style=flat-square&logo=gnubash&logoColor=white)
![TCP/IP](https://img.shields.io/badge/TCP_/_IP-333?style=flat-square)
![Firewall Policy](https://img.shields.io/badge/Firewall_Policy-444?style=flat-square)

---

## 🚀 Security Projects

### 🔴 Project Chakravyuh &nbsp; `In Development`
> **Next-Gen Autonomous Open-Source SOC Architecture**

```
Architecture:
  Log Ingestion → Correlation Engine → Threat Intel Enrichment
       ↓
  MITRE ATT&CK Playbook Execution → Automated Response
       ↓
  Alert Triage → Incident Ticketing → DFIR Handoff
```

| Component | Description |
|-----------|-------------|
| **SIEM Module** | Log ingestion, normalisation, correlation |
| **Threat Intel** | IOC enrichment, feed aggregation |
| **SOAR Engine** | Automated playbook execution |
| **EDR Integration** | Endpoint telemetry collection |
| **Compliance** | CERT-In, DPDP, SEBI CSCRF alignment |

[![Chakravyuh Repo](https://img.shields.io/badge/GitHub-Project_Chakravyuh-181717?style=for-the-badge&logo=github)](https://github.com/Harshk7771/Project-Chakravyuh)
[![Project Page](https://img.shields.io/badge/Notion-Project_Page-000?style=for-the-badge&logo=notion)](https://chakravyuhcyberops.notion.site/Harsh-Kumar-SOC-DFIR-Analyst-bebfd9803a324eb3b19aaac7767aab47)

---

### 🟢 HOGUN &nbsp; `Live`
> **Python-Based Web Scraping & OSINT Reconnaissance Tool**

```python
# Core capabilities
capabilities = [
    "Subdomain enumeration",
    "WHOIS & DNS lookup",
    "Metadata extraction from web sources",
    "Web-exposed data harvesting for DFIR",
    "Threat intelligence data collection",
]
```

| Use Case | Description |
|----------|-------------|
| **OSINT** | Open-source intelligence gathering |
| **Recon** | Target footprinting & subdomain mapping |
| **DFIR** | Forensic data collection from public sources |
| **Threat Intel** | Feed enrichment from web sources |

[![HOGUN Repo](https://img.shields.io/badge/GitHub-HOGUN-181717?style=for-the-badge&logo=github)](https://github.com/Harshk7771/HOGUN)

---

## 🏆 Security Recognition

```
┌─────────────────────────────────────────────────────────────┐
│  NCIIPC — National Critical Information Infrastructure      │
│           Protection Centre                                 │
│                                                             │
│  Responsibly disclosed 4 major vulnerabilities · 2024      │
│  Officially acknowledged for ethical security research      │
└─────────────────────────────────────────────────────────────┘
```

---

## 📜 Certifications

| Certification | Issuer | Year | Domain |
|--------------|--------|------|--------|
| ⭐ Windows Forensic Analysis Bootcamp | STDC — CDAC | 2025 | DFIR |
| ⭐ BelkaGPT: Effective AI in DFIR | Belkasoft | 2025 | DFIR · AI |
| ⭐ CSI Linux Certified Investigator | CSI Linux | 2024 | Investigation |
| ⭐ Junior Cyber Security Analyst | CISCO | 2024 | SOC |
| Advanced Digital Forensics Techniques | Belkasoft | 2024 | DFIR |
| Cyber Threat Intelligence 101 | arcx | 2024 | Threat Intel |
| Digital Forensics Essentials | EC-Council | 2024 | DFIR |
| Ethical Hacking Essentials | EC-Council | 2024 | Offensive |
| Network Defense Essentials | EC-Council | 2024 | Network |
| SysTools Email Forensic Essentials | SysTools | 2024 | DFIR |

---

## 💼 Technical Experience

```
Antivirus Engineer L1
└── Thoughtsol Infotech Pvt Ltd | BHEL Noida | Aug 2024 – Feb 2025
    ├── Checkpoint Security Gateway administration
    ├── EDR architecture & AV policy deployment (multi-site)
    ├── IPS, Anti-Malware, Integrity Monitoring, Log Inspection
    ├── Security incident triage & ITSM resolution workflows
    └── Python/Bash automation for vulnerability mitigation

DFIR Intern
└── IIMT Group of Colleges & FCRF | Remote | Jun – Aug 2024
    ├── Forensic investigations: Autopsy, FTK Imager
    ├── IR lifecycle: Identification → Containment → Eradication → Recovery
    └── Network traffic analysis: Wireshark, IOC reconstruction

Security Analyst Intern
└── Cryptus Cyber Security Pvt Ltd | Delhi | Jan – Jun 2024
    ├── Web application VAPT & vulnerability assessments
    ├── CVSS-scored reporting with remediation strategies
    └── Threat intelligence monitoring
```

---

## 📊 GitHub Stats

<div align="center">

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Harshk7771&show_icons=true&theme=dark&hide_border=true&count_private=true&bg_color=0d0d0d&title_color=c8f135&icon_color=c8f135&text_color=888888)

![Top Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=Harshk7771&layout=compact&theme=dark&hide_border=true&bg_color=0d0d0d&title_color=c8f135&text_color=888888)

![GitHub Streak](https://streak-stats.demolab.com?user=Harshk7771&theme=dark&hide_border=true&background=0d0d0d&ring=c8f135&fire=c8f135&currStreakLabel=c8f135)

</div>

---

<div align="center">

**Open to SOC Analyst · DFIR Analyst · Endpoint Security roles across India**

`Delhi, India` · `MCA Cybersecurity (Pursuing)` · `NCIIPC Researcher`

</div>
